<?php

namespace Plugin\SoftbankPayment4\Exception;

class SbpsException extends \Exception
{

}
