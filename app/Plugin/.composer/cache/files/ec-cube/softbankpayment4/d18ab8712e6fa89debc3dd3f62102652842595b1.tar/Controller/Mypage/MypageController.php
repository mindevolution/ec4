<?php

namespace Plugin\SoftbankPayment4\Controller\Mypage;

use Eccube\Controller\AbstractController;
use Plugin\SoftbankPayment4\Client\CreditCardInfoClient;
use Plugin\SoftbankPayment4\Exception\SbpsException;
use Plugin\SoftbankPayment4\Form\Type\CreditApiType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class MypageController extends AbstractController
{
    /**
     * @var CreditCardInfoClient
     */
    private $creditCardInfoClient;

    public function __construct(CreditCardInfoClient $creditCardInfoClient)
    {
        $this->creditCardInfoClient = $creditCardInfoClient;
    }

    /**
     * @Route("/mypage/sbps/credit/index", name="sbps_credit_list")
     * @Template("@SoftbankPayment4/default/mypage/credit/index.twig")
     */
    public function index()
    {
        try {
            $response = $this->creditCardInfoClient
                ->setCustomer($this->getUser())
                ->implement();
        } catch (SbpsException $e) {
            $message = 'カード情報の取得に失敗しました。';
            $message.= '(エラーコード: ' . $e->getCode() . ')';
            $this->addError($message);
            return $this->redirectToRoute('mypage');
        } catch (\Exception $e) {
            $this->addError('システム上で予期しないエラーが発生しました。');
            return $this->redirectToRoute('mypage');
        }

        if ($response === null) {
            $arrCardInfo['result'] = 'NG';
        } else {
            $arrNum = str_split($response['cc_number'], 4);
            $arrExpiration = str_split($response['cc_expiration'], 4);

            $arrCardInfo = [
                'result' => 'OK',
                'card_num_1' => $arrNum[0],
                'card_num_2' => $arrNum[1],
                'card_num_3' => $arrNum[2],
                'card_num_4' => $arrNum[3],
                'expiration_year' => $arrExpiration[0],
                'expiration_month' => $arrExpiration[1],
            ];
        }

        return [
            'cardInfo' => $arrCardInfo,
        ];
    }

    /**
     * @Route("/mypage/sbps/credit/new", name="sbps_credit_store")
     * @Template("@SoftbankPayment4/default/mypage/credit/edit.twig")
     *
     * @param Request $request
     * @return array|RedirectResponse
     */
    public function store(Request $request)
    {
        $form = $this->createForm(CreditApiType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {
                $this->creditCardInfoClient
                    ->setCustomer($this->getUser())
                    ->store($request->request->get('credit_api'));
            } catch (SbpsException $e) {
                $message = 'カード情報の登録に失敗しました。';
                $message.= '(エラーコード: ' . $e->getCode() . ')';
                $this->addError($message);
            } catch (\Exception $e) {
                $this->addError('システム上で予期しないエラーが発生しました。');
            }

            return $this->redirectToRoute('sbps_credit_list');
        }

        return [
            'form' => $form->createView(),
        ];
    }

    /**
     * @Route("/mypage/sbps/credit/edit", name="sbps_credit_update")
     * @Template("@SoftbankPayment4/default/mypage/credit/edit.twig")
     *
     * @param Request $request
     * @return array|RedirectResponse
     */
    public function update(Request $request)
    {
        $form = $this->createForm(CreditApiType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {
                $this->creditCardInfoClient
                    ->setCustomer($this->getUser())
                    ->update($request->request->get('credit_api'));
            } catch (SbpsException $e) {
                $message = 'カード情報の更新に失敗しました。';
                $message.= '(エラーコード: ' . $e->getCode() . ')';
                $this->addError($message);
            } catch (\Exception $e) {
                $this->addError('システム上で予期しないエラーが発生しました。');
            }

            return $this->redirectToRoute('sbps_credit_list');
        }

        return [
            'form' => $form->createView(),
        ];
    }

    /**
     * @Route("/mypage/sbps/credit/delete", name="sbps_credit_delete", methods={"DELETE"})
     */
    public function delete()
    {
        try {
            $this->creditCardInfoClient
                ->setCustomer($this->getUser())
                ->delete();
        } catch (SbpsException $e) {
            $message = 'カード情報の削除に失敗しました。';
            $message.= '(エラーコード: ' . $e->getCode() . ')';
            $this->addError($message);
        } catch (\Exception $e) {
            $this->addError('システム上で予期しないエラーが発生しました。');
        }

        return $this->redirectToRoute('sbps_credit_list');
    }
}