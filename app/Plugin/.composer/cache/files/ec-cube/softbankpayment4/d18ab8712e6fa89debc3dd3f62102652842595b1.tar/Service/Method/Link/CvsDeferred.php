<?php

namespace Plugin\SoftbankPayment4\Service\Method\Link;

use Plugin\SoftbankPayment4\Service\Method\Link\LinkBase;

class CvsDeferred extends LinkBase
{
}
